from flask import Flask, render_template, flash, redirect, url_for, session, request, logging
from wtforms import Form, StringField, TextAreaField, PasswordField, validators, DateField, IntegerField
from flask_wtf.file import FileField, FileRequired, FileAllowed
from flask_mysqldb import MySQL
from passlib.hash import sha256_crypt
from functools import wraps

app = Flask(__name__)
app.secret_key = 'atcgaming'


#config SQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Levan001#'
app.config['MYSQL_DB'] = 'atcgaming'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

# Init MYSQL
mysql = MySQL(app)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/products')
def products():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM atc4')
    atc4 = cur.fetchall()
    cur.execute('SELECT * FROM atc3')
    atc3 = cur.fetchall()
    return render_template('products.html',atc4 = atc4,atc3 = atc3)

@app.route('/faqs')
def faqs():
    return render_template('faqs.html')

@app.route('/details/<string:id>/')
def details(id):
        cur = mysql.connection.cursor()
        cur.execute('SELECT * FROM atc4 WHERE id = %s', [id])
        id = cur.fetchone()
        return render_template('details.html',id = id)

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method =='POST':
        username = request.form['Username']
        password_candidate = request.form['Password']

        # Create cursor
        cur = mysql.connection.cursor()

        # Get User by username
        result = cur.execute("SELECT * FROM users WHERE username = %s", [username])
        if result >0:
            data = cur.fetchone()
            password = data['password']

            # Compare password
            if sha256_crypt.verify(password_candidate, password):
                session["logged_in"] = True
                session["username"] = username

                flash("You are now logged in", 'success')
                return redirect(url_for('dashboard'))
            else:
                error = "Invalid login"
                return render_template('login.html', error = error)
            cur.close()
        else:
            error = 'Username not found'
            return render_template('login.html', error = error)
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You are now logged out','success')
    return redirect(url_for('index'))

class RegisterForm(Form):
    name = StringField ('Name', [validators.length(min=1, max=50)])
    username = StringField ('Username', [validators.length(min=4, max=25)])
    email = StringField ('Email', [validators.length(min=6,max=50)])
    password = PasswordField ('Password',[validators.DataRequired(),validators.
        EqualTo('confirm', message='Password does not match')])
    confirm = PasswordField ('Confirm password')

@app.route('/register', methods=['GET','POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        name = form.name.data
        email = form.email.data
        username = form.username.data
        password = sha256_crypt.encrypt(str(form.password.data))

        # Create cursor
        cur = mysql.connection.cursor()
        cur.execute("Insert into users(name,email,username,password) values (%s, %s, %s, %s) ", (name, email, username, password))

        # Commit to DB
        mysql.connection.commit()

        # Close Connection
        cur.close()

        flash("You are now registered and can login", "success")
        return redirect(url_for('index'))

    return render_template('register.html', form = form)

 #Check if user logged in
def is_logged_in(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
           return f(*args, **kwargs)
        else:
            flash('Unauthorized, Please login', "danger")
            return redirect(url_for('login'))
    return wrap



@app.route('/dashboard')
@ is_logged_in
def dashboard():
        return render_template('dashboard.html')

@app.route('/profile')
@ is_logged_in
def profile():
    # We need all the account info for the user so we can display it on the profile page
        cur = mysql.connection.cursor()
        cur.execute('SELECT * FROM users WHERE username = %s', [session['username']])
        users = cur.fetchone()
        # Show the profile page with account info
        return render_template('profile.html',users=users)

class productform(Form):
    id = StringField('Id')
    title = StringField ('Title')
    description = TextAreaField ('Description')
    release_date = DateField ()
    price = IntegerField ()

@app.route('/addproduct', methods = ['GET','POST'])
@is_logged_in
def add_product():
    form = productform(request.form)
    if request.method == 'POST' and form.validate():
        id = form.id.data
        title = form.title.data
        description = form.description.data
        release_date = form.release_date.data
        price = form.price.data

        cur = mysql.connection.cursor()

        cur.execute ("INSERT INTO atc4 (id,title,description,release_date,price) VALUES (%s,%s,%s,%s,%s)", (id,title,description,release_date,price))

        mysql.connection.commit()

        cur.close()
        flash('Product Added', 'success')
        return redirect(url_for('dashboard'))

    return render_template('addproduct.html', form = form)


@app.route('/editproduct')
@is_logged_in
def editproduct():
    cur = mysql.connection.cursor()

    result = cur.execute("SELECT * FROM atc4")

    atc4 = cur.fetchall()

    if result > 0:
        return render_template('editproduct.html', atc4 = atc4 )
    else:
        msg = "No Product Found"
        return render_template('editproduct.html', msg = msg)

    cur.close()
    return render_template('edit_product.html')



@app.route('/edit_atc4/<string:id>',methods=['GET','POST'])
@is_logged_in
def edit_atc4(id):
    cur = mysql.connection.cursor()

    result = cur.execute("SELECT * FROM atc4 where id = %s",[id])
    atc4 = cur.fetchone()
    cur.close()

    form = productform(request.form)

    form.title.data = atc4['title']
    form.description.data = atc4['description']
    form.release_date.data = atc4['release_date']
    form.price.data = atc4['price']

    if request.method == "POST" and form.validate():
        title = request.form['title']
        description = request.form['description']
        release_date = request.form['release_date']
        price = request.form['price']

        cur = mysql.connection.cursor()

        cur.execute("UPDATE atc4 SET title = %s, description = %s, release_date = %s, price = %s WHERE id = %s", (title, description, release_date, price, id))

        mysql.connection.commit()

        cur.close()

        flash("Product Update Complete",'success')
        return redirect(url_for('editproduct'))
    
    return render_template('edit_atc4.html', form=form)


@app.route('/delete_atc4/<string:id>', methods=["POST"])
@is_logged_in
def delete_atc4(id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE  FROM atc4 WHERE id = %s", [id])
    mysql.connection.commit()
    cur.close()
    flash("Product Deleted",'success')
    return redirect(url_for('editproduct'))

class userform(Form):
    name = StringField ('name', [validators.length(min=4, max=25)])
    email = StringField ('Email', [validators.length(min=6,max=50)])


@app.route('/edit',methods=['GET','POST'])
@is_logged_in
def edit():
    cur = mysql.connection.cursor()

    result = cur.execute("SELECT * FROM users where username = %s",[session['username']])
    users = cur.fetchone()
    cur.close()

    form = userform(request.form)

    form.email.data = users['email']
    form.name.data = users['name']

    if request.method == "POST" and form.validate():
        email = request.form['email']
        name = request.form['name']

        cur = mysql.connection.cursor()

        cur.execute("UPDATE users SET email = %s, name = %s WHERE username = %s", (email, name,[session['username']]))

        mysql.connection.commit()

        cur.close()

        flash("Profile Update Complete",'success')
        return redirect(url_for('profile'))
    
    return render_template('edit.html', form=form)





if __name__ == "__main__":
    app.run(port=8000,debug=True)